# summer_inst_basic
These are the exercise for the basics on javascript
